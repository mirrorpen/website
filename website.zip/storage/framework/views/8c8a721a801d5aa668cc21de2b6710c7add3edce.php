<?php $__env->startSection('title', '登录'); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-offset-2 col-md-8">
    <div class="panel panel-default">
        <div class="panel-heading">
            <h4>登录</h4>
        </div>
        <div class="panel-body">
            <?php echo $__env->make('shared._errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <form action="<?php echo e(route('login')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label for="email">邮箱：</label>
                    <input type="text" name="email" class="form-control" value="<?php echo e(old('email')); ?>">
                </div>

                <div class="form-group">
                    <label for="password">密码（<a onclick="heihei()">忘记密码?</a>）：</label>
                    <input type="password" name="password" class="form-control" value="<?php echo e(old('password')); ?>">
                </div>

                <div class="checkbox">
                    <label><input type="checkbox" name="remember">记住爸爸</label>
                </div>

                <button type="submit" class="btn btn-primary">登录</button>
            </form>
            <hr>

            <p>
                还没有账号？<a href="<?php echo e(route('signup')); ?>">立即注册，成为本站的爸爸！</a>
            </p>
        </div>
    </div>
</div>

    <script>
        function heihei() {
            alert('那我也没办法');
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>