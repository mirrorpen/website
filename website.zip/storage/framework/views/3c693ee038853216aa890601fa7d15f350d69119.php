<div class="col-md-12">
    <footer class="footer">
        <small class="slogon">
            <a href="#">
                林深时见鹿<br/>
                海深时见鲸
            </a>
        </small>
        <ul>
            <li><a href="<?php echo e(route('about')); ?>">关于</a></li>
        </ul>
    </footer>
</div>